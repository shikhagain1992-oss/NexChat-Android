# NexChat Android — Phase 2 (বাংলা)

এই ZIP-এ Phase 1-এর ওপর নতুন Phase 2 যোগ করা হয়েছে; Phase 1 আবার কপি করে আলাদা করে বানানো হয়নি।

## Phase 2-তে যোগ হয়েছে
- Email-এ ৬ সংখ্যার OTP চাওয়ার ও যাচাইয়ের স্ক্রিন।
- SMS/Phone OTP screen, route ও client-side phone OTP call সরানো হয়েছে।
- OTP তৈরি, hash করে রাখা, মেয়াদ ৫ মিনিট, resend cooldown ৬০ সেকেন্ড, সর্বোচ্চ ৫ বার ভুল চেষ্টা এবং একবার ব্যবহারযোগ্য code—সব trusted Firebase Cloud Functions-এ।
- যাচাই সফল হলে Firebase custom token দিয়ে sign-in।
- Android native splash: কমপক্ষে ২.৩ সেকেন্ড; এই সময়েই saved session check হবে। আলাদা Flutter loading/spinner page দেখানো হবে না।
- পুরোনো session থাকলে Dashboard; না থাকলে Email login।

## চালু করার আগে মালিকের সেটআপ লাগবে
নিজের Firebase project, Android Firebase config, Firebase Functions deploy, Resend verified sender/API key এবং Firebase App Check configure না করলে বাস্তবে Email OTP পাঠানো যাবে না। এগুলো কোনো গোপন key ZIP-এ রাখা হয়নি। বিস্তারিত `docs/phase2/PHASE2_EMAIL_OTP.md`-এ।

## যাচাইয়ের সীমাবদ্ধতা
এই environment-এ Flutter SDK নেই। তাই Dart analyze, Android build, OTP email delivery বা ফোনে splash/session test চালানো যায়নি। এটি Phase 2 source implementation; APK বা সম্পূর্ণ চালু app নয়।
