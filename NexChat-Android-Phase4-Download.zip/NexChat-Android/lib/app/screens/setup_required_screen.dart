import 'package:flutter/material.dart';

class SetupRequiredScreen extends StatelessWidget {
  const SetupRequiredScreen({Key? key, required this.reason}) : super(key: key);

  final String reason;

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Container(
                    height: 76,
                    width: 76,
                    decoration: BoxDecoration(
                      color: colors.primaryContainer,
                      borderRadius: BorderRadius.circular(24),
                    ),
                    child: Icon(Icons.chat_bubble_rounded, size: 38, color: colors.primary),
                  ),
                  const SizedBox(height: 22),
                  Text('NexChat Android', style: Theme.of(context).textTheme.headlineMedium?.copyWith(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 8),
                  Text(
                    'Project foundation is ready',
                    style: Theme.of(context).textTheme.titleMedium?.copyWith(color: colors.primary),
                  ),
                  const SizedBox(height: 22),
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(18),
                      child: Column(
                        children: [
                          const Icon(Icons.cloud_off_rounded, size: 30),
                          const SizedBox(height: 12),
                          Text('Firebase setup is required', style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
                          const SizedBox(height: 8),
                          const Text(
                            'এই প্রজেক্টে এখনো তোমার নিজস্ব Firebase configuration যোগ করা হয়নি। নিরাপত্তার জন্য অন্য কোনো প্রজেক্টের configuration ব্যবহার করা হচ্ছে না।',
                            textAlign: TextAlign.center,
                          ),
                          const SizedBox(height: 12),
                          Text(reason, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: colors.onSurfaceVariant), textAlign: TextAlign.center),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  const Text(
                    'পরবর্তী ধাপে Email OTP authentication এবং Firebase connection তৈরি করা হবে। SMS OTP এই অ্যাপে থাকবে না।',
                    textAlign: TextAlign.center,
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
