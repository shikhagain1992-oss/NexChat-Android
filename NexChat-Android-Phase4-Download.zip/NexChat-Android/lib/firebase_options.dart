// Firebase options are intentionally placeholders.
// Generate this file for YOUR Firebase project with FlutterFire CLI before running.
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    throw UnsupportedError(
      'NexChat Android Firebase is not configured yet. Add your own Firebase project configuration and regenerate firebase_options.dart.',
    );
  }
}
