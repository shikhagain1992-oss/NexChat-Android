import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:nexchat_android/features/chat/screens/mobile_chat_screen.dart';

/// Email-based discovery for accounts that use email OTP instead of phone OTP.
class FindPeopleScreen extends StatefulWidget {
  static const routeName = '/find-people';
  const FindPeopleScreen({Key? key}) : super(key: key);

  @override
  State<FindPeopleScreen> createState() => _FindPeopleScreenState();
}

class _FindPeopleScreenState extends State<FindPeopleScreen> {
  final _email = TextEditingController();
  bool _searching = false;
  Map<String, dynamic>? _result;
  String? _message;

  Future<void> _search() async {
    final email = _email.text.trim().toLowerCase();
    if (!email.contains('@') || !email.contains('.')) {
      setState(() { _result = null; _message = 'একটি সঠিক Email address লেখো।'; });
      return;
    }
    setState(() { _searching = true; _result = null; _message = null; });
    try {
      final snapshot = await FirebaseFirestore.instance.collection('users')
          .where('email', isEqualTo: email).limit(1).get();
      if (!mounted) return;
      if (snapshot.docs.isEmpty) {
        setState(() => _message = 'এই Email দিয়ে কোনো NexChat Android account পাওয়া যায়নি।');
      } else if (snapshot.docs.first.id == FirebaseAuth.instance.currentUser?.uid) {
        setState(() => _message = 'এটি তোমার নিজের account।');
      } else {
        setState(() => _result = snapshot.docs.first.data());
      }
    } catch (_) {
      if (mounted) setState(() => _message = 'Search করা যায়নি। Firebase ও internet connection পরীক্ষা করো।');
    } finally {
      if (mounted) setState(() => _searching = false);
    }
  }

  @override
  void dispose() { _email.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final result = _result;
    return Scaffold(
      appBar: AppBar(title: const Text('Find people')),
      body: ListView(padding: const EdgeInsets.all(20), children: [
        const Text('Email address দিয়ে NexChat Android ব্যবহারকারী খুঁজে নাও।', style: TextStyle(fontSize: 15)),
        const SizedBox(height: 18),
        TextField(
          controller: _email,
          keyboardType: TextInputType.emailAddress,
          textInputAction: TextInputAction.search,
          onSubmitted: (_) => _search(),
          decoration: InputDecoration(
            labelText: 'Email address', prefixIcon: const Icon(Icons.email_outlined),
            suffixIcon: IconButton(onPressed: _searching ? null : _search, icon: const Icon(Icons.search)),
            border: const OutlineInputBorder(),
          ),
        ),
        const SizedBox(height: 14),
        FilledButton(onPressed: _searching ? null : _search,
          child: _searching ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Text('Search')),
        if (_message != null) Padding(padding: const EdgeInsets.only(top: 18), child: Text(_message!, textAlign: TextAlign.center)),
        if (result != null) ...[
          const SizedBox(height: 22),
          Card(child: ListTile(
            leading: CircleAvatar(
              backgroundImage: (result['profilePic'] as String? ?? '').isNotEmpty ? NetworkImage(result['profilePic']) : null,
              child: (result['profilePic'] as String? ?? '').isEmpty ? const Icon(Icons.person_outline) : null,
            ),
            title: Text(result['name'] as String? ?? 'NexChat user'),
            subtitle: Text(result['about'] as String? ?? 'Hey there! I am using NexChat Android.'),
            trailing: const Icon(Icons.chat_bubble_outline),
            onTap: () {
              Navigator.pushNamed(context, MobileChatScreen.routeName, arguments: {
                'name': result['name'] ?? 'NexChat user',
                'uid': result['uid'],
                'isGroupChat': false,
                'profilePic': result['profilePic'] ?? '',
              });
            },
          )),
        ],
      ]),
    );
  }
}
