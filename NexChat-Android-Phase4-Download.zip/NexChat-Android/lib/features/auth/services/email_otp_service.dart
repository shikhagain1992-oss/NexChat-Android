import 'package:cloud_functions/cloud_functions.dart';
import 'package:firebase_auth/firebase_auth.dart';

/// Email OTP is verified by a trusted Cloud Function. No OTP or mail secret
/// is generated/stored in the Android client.
class EmailOtpService {
  EmailOtpService({FirebaseFunctions? functions, FirebaseAuth? auth})
      : _functions = functions ?? FirebaseFunctions.instance,
        _auth = auth ?? FirebaseAuth.instance;

  final FirebaseFunctions _functions;
  final FirebaseAuth _auth;

  Future<void> requestCode(String email) async {
    final callable = _functions.httpsCallable('requestEmailOtp');
    await callable.call(<String, dynamic>{'email': email.trim().toLowerCase()});
  }

  Future<UserCredential> verifyCode({required String email, required String code}) async {
    final callable = _functions.httpsCallable('verifyEmailOtp');
    final result = await callable.call(<String, dynamic>{
      'email': email.trim().toLowerCase(),
      'code': code.trim(),
    });
    final data = Map<String, dynamic>.from(result.data as Map);
    final customToken = data['customToken'] as String?;
    if (customToken == null || customToken.isEmpty) {
      throw FirebaseAuthException(code: 'invalid-server-response');
    }
    return _auth.signInWithCustomToken(customToken);
  }
}
