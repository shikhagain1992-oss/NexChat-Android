import 'package:flutter/material.dart';
import 'package:nexchat_android/features/auth/services/email_otp_service.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:nexchat_android/features/auth/screens/user_information_screen.dart';
import 'package:nexchat_android/mobile_layout_screen.dart';

class LoginScreen extends StatefulWidget {
  static const routeName = '/login-screen';
  const LoginScreen({Key? key}) : super(key: key);

  @override
  State<LoginScreen> createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final _email = TextEditingController();
  final _code = TextEditingController();
  final _service = EmailOtpService();
  bool _codeSent = false;
  bool _busy = false;

  @override
  void dispose() {
    _email.dispose();
    _code.dispose();
    super.dispose();
  }

  Future<void> _run(Future<void> Function() action) async {
    if (_busy) return;
    setState(() => _busy = true);
    try {
      await action();
    } catch (e) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(_friendlyError(e))),
      );
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  String _friendlyError(Object error) {
    final value = error.toString();
    if (value.contains('unavailable') || value.contains('not-found')) {
      return 'Email OTP সার্ভার এখনো configure করা হয়নি। Firebase backend setup প্রয়োজন।';
    }
    return 'কাজটি সম্পন্ন হয়নি। ইন্টারনেট ও Email ঠিকানা পরীক্ষা করে আবার চেষ্টা করো।';
  }

  @override
  Widget build(BuildContext context) {
    final colors = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('NexChat Android')),
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 440),
              child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Icon(Icons.mark_email_read_rounded, size: 66, color: colors.primary),
                const SizedBox(height: 20),
                Text(_codeSent ? 'কোড যাচাই করো' : 'Email দিয়ে শুরু করো',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                const SizedBox(height: 10),
                Text(_codeSent ? 'তোমার ইমেলে পাঠানো ৬ সংখ্যার কোডটি লেখো।' : 'তোমার Email address-এ ৬ সংখ্যার verification code পাঠানো হবে।', textAlign: TextAlign.center),
                const SizedBox(height: 28),
                TextField(controller: _email, enabled: !_codeSent,
                  keyboardType: TextInputType.emailAddress,
                  decoration: const InputDecoration(labelText: 'Email address', prefixIcon: Icon(Icons.email_outlined))),
                if (_codeSent) ...[
                  const SizedBox(height: 14),
                  TextField(controller: _code, keyboardType: TextInputType.number,
                    maxLength: 6, decoration: const InputDecoration(labelText: '৬ সংখ্যার Email OTP', prefixIcon: Icon(Icons.password))),
                ],
                const SizedBox(height: 14),
                FilledButton(
                  onPressed: _busy ? null : () => _run(() async {
                    if (!_codeSent) {
                      if (!_email.text.contains('@')) throw Exception('invalid-email');
                      await _service.requestCode(_email.text);
                      if (mounted) setState(() => _codeSent = true);
                    } else {
                      if (_code.text.trim().length != 6) throw Exception('invalid-code');
                      final credential = await _service.verifyCode(email: _email.text, code: _code.text);
                      final profile = await FirebaseFirestore.instance.collection('users').doc(credential.user!.uid).get();
                      if (mounted) {
                        Navigator.of(context).pushAndRemoveUntil(
                          MaterialPageRoute(builder: (_) => profile.exists ? const MobileLayoutScreen() : const UserInformationScreen()),
                          (route) => false,
                        );
                      }
                    }
                  }),
                  child: Padding(padding: const EdgeInsets.symmetric(vertical: 15),
                    child: _busy ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(strokeWidth: 2)) : Text(_codeSent ? 'Verify & Login' : 'Send Email OTP')),
                ),
                if (_codeSent) TextButton(onPressed: _busy ? null : () => setState(() { _codeSent = false; _code.clear(); }), child: const Text('অন্য Email ব্যবহার করো')),
                const SizedBox(height: 8),
                Text('শুধু Email OTP ব্যবহার করা হবে। SMS বা ফোন OTP নয়।', textAlign: TextAlign.center, style: Theme.of(context).textTheme.bodySmall?.copyWith(color: colors.onSurfaceVariant)),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
