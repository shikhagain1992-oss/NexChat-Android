import 'dart:io';

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter/material.dart';
import 'package:nexchat_android/common/utils/utils.dart';
import 'package:nexchat_android/features/landing/screens/landing_screen.dart';

/// Profile view and editor. Profile data is stored under users/{uid}.
class ProfileScreen extends StatefulWidget {
  static const routeName = '/profile';
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  State<ProfileScreen> createState() => _ProfileScreenState();
}

class _ProfileScreenState extends State<ProfileScreen> {
  final _name = TextEditingController();
  final _about = TextEditingController();
  File? _pickedImage;
  bool _editing = false;
  bool _saving = false;
  bool _loaded = false;
  String _photoUrl = '';
  String _email = '';

  User? get _user => FirebaseAuth.instance.currentUser;
  DocumentReference<Map<String, dynamic>> get _profileRef =>
      FirebaseFirestore.instance.collection('users').doc(_user!.uid);

  @override
  void initState() {
    super.initState();
    _email = _user?.email ?? '';
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final user = _user;
    if (user == null) return;
    try {
      final snapshot = await FirebaseFirestore.instance.collection('users').doc(user.uid).get();
      final data = snapshot.data() ?? <String, dynamic>{};
      if (!mounted) return;
      _name.text = (data['name'] as String?) ?? user.displayName ?? '';
      _about.text = (data['about'] as String?) ?? 'Hey there! I am using NexChat Android.';
      _photoUrl = (data['profilePic'] as String?) ?? user.photoURL ?? '';
      setState(() => _loaded = true);
    } catch (_) {
      if (mounted) setState(() => _loaded = true);
      _message('প্রোফাইল লোড করা যায়নি। ইন্টারনেট সংযোগ পরীক্ষা করো।');
    }
  }

  Future<void> _choosePhoto() async {
    final image = await pickImageFromGallery(context);
    if (image != null && mounted) setState(() => _pickedImage = image);
  }

  Future<void> _save() async {
    final user = _user;
    final name = _name.text.trim();
    if (user == null || name.isEmpty) {
      _message('নাম লিখতে হবে।');
      return;
    }
    if (name.length > 40 || _about.text.trim().length > 139) {
      _message('নাম সর্বোচ্চ ৪০ এবং About সর্বোচ্চ ১৩৯ অক্ষর হতে পারে।');
      return;
    }
    setState(() => _saving = true);
    try {
      var photoUrl = _photoUrl;
      if (_pickedImage != null) {
        final ref = FirebaseStorage.instance.ref().child('profilePic/${user.uid}/avatar.jpg');
        final task = await ref.putFile(_pickedImage!);
        photoUrl = await task.ref.getDownloadURL();
      }
      await _profileRef.set({
        'uid': user.uid,
        'name': name,
        'email': user.email ?? '',
        'profilePic': photoUrl,
        'about': _about.text.trim(),
        'updatedAt': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));
      await user.updateDisplayName(name);
      if (photoUrl.isNotEmpty) await user.updatePhotoURL(photoUrl);
      if (!mounted) return;
      setState(() {
        _photoUrl = photoUrl;
        _pickedImage = null;
        _editing = false;
      });
      _message('প্রোফাইল আপডেট হয়েছে।');
    } catch (_) {
      _message('প্রোফাইল সেভ হয়নি। Firebase Storage/Firestore সেটআপ পরীক্ষা করো।');
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  Future<void> _signOut() async {
    await FirebaseAuth.instance.signOut();
    if (!mounted) return;
    Navigator.of(context).pushAndRemoveUntil(
      MaterialPageRoute(builder: (_) => const LandingScreen()),
      (route) => false,
    );
  }

  void _message(String text) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(text)));
  }

  @override
  void dispose() {
    _name.dispose();
    _about.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final imageProvider = _pickedImage != null
        ? FileImage(_pickedImage!) as ImageProvider
        : (_photoUrl.isNotEmpty ? NetworkImage(_photoUrl) as ImageProvider : null);
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Profile'),
        actions: [
          if (!_editing)
            IconButton(onPressed: _loaded ? () => setState(() => _editing = true) : null,
              tooltip: 'Edit profile', icon: const Icon(Icons.edit_outlined)),
        ],
      ),
      body: !_loaded
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.fromLTRB(24, 28, 24, 32),
              children: [
                Center(
                  child: Stack(children: [
                    CircleAvatar(
                      radius: 58,
                      backgroundColor: theme.colorScheme.primaryContainer,
                      backgroundImage: imageProvider,
                      child: imageProvider == null
                          ? Icon(Icons.person_rounded, size: 58, color: theme.colorScheme.primary)
                          : null,
                    ),
                    if (_editing)
                      Positioned(right: 0, bottom: 0,
                        child: Material(
                          color: theme.colorScheme.primary,
                          shape: const CircleBorder(),
                          child: IconButton(onPressed: _choosePhoto, color: Colors.white,
                            icon: const Icon(Icons.camera_alt_outlined)),
                        )),
                  ]),
                ),
                const SizedBox(height: 28),
                TextField(
                  controller: _name,
                  readOnly: !_editing,
                  maxLength: 40,
                  decoration: const InputDecoration(labelText: 'নাম', prefixIcon: Icon(Icons.person_outline)),
                ),
                const SizedBox(height: 14),
                TextFormField(
                  initialValue: _email,
                  readOnly: true,
                  decoration: const InputDecoration(labelText: 'Email', prefixIcon: Icon(Icons.email_outlined)),
                ),
                const SizedBox(height: 14),
                TextField(
                  controller: _about,
                  readOnly: !_editing,
                  maxLength: 139,
                  maxLines: 3,
                  decoration: const InputDecoration(labelText: 'About', alignLabelWithHint: true, prefixIcon: Icon(Icons.info_outline)),
                ),
                const SizedBox(height: 22),
                if (_editing)
                  FilledButton.icon(
                    onPressed: _saving ? null : _save,
                    icon: _saving ? const SizedBox(width: 18, height: 18, child: CircularProgressIndicator(strokeWidth: 2)) : const Icon(Icons.save_outlined),
                    label: Text(_saving ? 'Saving…' : 'Save profile'),
                  )
                else
                  OutlinedButton.icon(
                    onPressed: () => setState(() => _editing = true),
                    icon: const Icon(Icons.edit_outlined), label: const Text('Edit profile'),
                  ),
                const SizedBox(height: 12),
                TextButton.icon(
                  onPressed: _signOut,
                  icon: const Icon(Icons.logout_rounded),
                  label: const Text('Log out'),
                  style: TextButton.styleFrom(foregroundColor: theme.colorScheme.error),
                ),
              ],
            ),
    );
  }
}
