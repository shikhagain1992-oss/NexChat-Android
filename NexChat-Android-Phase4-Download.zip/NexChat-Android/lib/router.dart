import 'dart:io';

import 'package:flutter/material.dart';
import 'package:nexchat_android/common/widgets/error.dart';
import 'package:nexchat_android/features/auth/screens/login_screen.dart';
import 'package:nexchat_android/features/auth/screens/user_information_screen.dart';
import 'package:nexchat_android/features/profile/screens/profile_screen.dart';
import 'package:nexchat_android/features/contacts/screens/find_people_screen.dart';
import 'package:nexchat_android/features/group/screens/create_group_screen.dart';
import 'package:nexchat_android/features/select_contacts/screens/select_contacts_screen.dart';
import 'package:nexchat_android/features/chat/screens/mobile_chat_screen.dart';
import 'package:nexchat_android/features/status/screens/confirm_status_screen.dart';
import 'package:nexchat_android/features/status/screens/status_screen.dart';
import 'package:nexchat_android/models/status_model.dart';

Route<dynamic> generateRoute(RouteSettings settings) {
  switch (settings.name) {
    case LoginScreen.routeName:
      return MaterialPageRoute(
        builder: (context) => const LoginScreen(),
      );
    case UserInformationScreen.routeName:
      return MaterialPageRoute(
        builder: (context) => const UserInformationScreen(),
      );
    case ProfileScreen.routeName:
      return MaterialPageRoute(
        builder: (context) => const ProfileScreen(),
      );
    case FindPeopleScreen.routeName:
      return MaterialPageRoute(
        builder: (context) => const FindPeopleScreen(),
      );
    case SelectContactsScreen.routeName:
      return MaterialPageRoute(
        builder: (context) => const SelectContactsScreen(),
      );
    case MobileChatScreen.routeName:
      final arguments = settings.arguments as Map<String, dynamic>;
      final name = arguments['name'];
      final uid = arguments['uid'];
      final isGroupChat = arguments['isGroupChat'];
      final profilePic = arguments['profilePic'];
      return MaterialPageRoute(
        builder: (context) => MobileChatScreen(
          name: name,
          uid: uid,
          isGroupChat: isGroupChat,
          profilePic: profilePic,
        ),
      );
    case ConfirmStatusScreen.routeName:
      final file = settings.arguments as File;
      return MaterialPageRoute(
        builder: (context) => ConfirmStatusScreen(
          file: file,
        ),
      );
    case StatusScreen.routeName:
      final status = settings.arguments as Status;
      return MaterialPageRoute(
        builder: (context) => StatusScreen(
          status: status,
        ),
      );
    case CreateGroupScreen.routeName:
      return MaterialPageRoute(
        builder: (context) => const CreateGroupScreen(),
      );
    default:
      return MaterialPageRoute(
        builder: (context) => const Scaffold(
          body: ErrorScreen(error: 'This page doesn\'t exist'),
        ),
      );
  }
}
