import 'dart:async';

import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_native_splash/flutter_native_splash.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:nexchat_android/app/screens/setup_required_screen.dart';
import 'package:nexchat_android/app/theme/app_theme.dart';
import 'package:nexchat_android/features/landing/screens/landing_screen.dart';
import 'package:nexchat_android/firebase_options.dart';
import 'package:nexchat_android/router.dart';
import 'package:nexchat_android/mobile_layout_screen.dart';

Future<void> main() async {
  final binding = WidgetsFlutterBinding.ensureInitialized();
  FlutterNativeSplash.preserve(widgetsBinding: binding);
  final startedAt = DateTime.now();
  String? firebaseError;
  User? initialUser;
  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);
    // Read Firebase's persisted local session. Do not wait for a network round-trip.
    initialUser = FirebaseAuth.instance.currentUser;
    if (initialUser == null) {
      try {
        initialUser = await FirebaseAuth.instance.authStateChanges().first.timeout(
          const Duration(seconds: 5), onTimeout: () => FirebaseAuth.instance.currentUser,
        );
      } catch (_) {
        initialUser = FirebaseAuth.instance.currentUser;
      }
    }
  } catch (error) {
    firebaseError = error.toString();
  }
  final elapsed = DateTime.now().difference(startedAt);
  const minimumSplash = Duration(milliseconds: 2300);
  if (elapsed < minimumSplash) await Future.delayed(minimumSplash - elapsed);
  runApp(ProviderScope(child: NexChatApp(
    firebaseReady: firebaseError == null, firebaseError: firebaseError,
    initiallySignedIn: initialUser != null,
  )));
  // Keep the native launch screen until Flutter has painted the resolved route.
  WidgetsBinding.instance.addPostFrameCallback((_) => FlutterNativeSplash.remove());
}

class NexChatApp extends StatelessWidget {
  const NexChatApp({Key? key, required this.firebaseReady, this.firebaseError, required this.initiallySignedIn}) : super(key: key);
  final bool firebaseReady;
  final String? firebaseError;
  final bool initiallySignedIn;

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false, title: 'NexChat Android',
      theme: NexChatTheme.light(), darkTheme: NexChatTheme.dark(), themeMode: ThemeMode.system,
      onGenerateRoute: generateRoute,
      home: !firebaseReady
        ? SetupRequiredScreen(reason: firebaseError ?? 'Firebase is not configured.')
        : initiallySignedIn ? const MobileLayoutScreen() : const LandingScreen(),
    );
  }
}
