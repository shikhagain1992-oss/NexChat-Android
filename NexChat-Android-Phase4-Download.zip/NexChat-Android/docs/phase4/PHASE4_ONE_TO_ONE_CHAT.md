# Phase 4 — One-to-One Chat

## Included in this increment

- Direct text messages are written to Firestore for both participants.
- Both chat previews and both message copies are committed in one Firestore batch.
- Message text is trimmed, empty messages are ignored, and text is capped at 4,000 characters.
- Reply metadata from the existing reply UI is preserved.
- Existing real-time Firestore message streams and read-receipt UI are retained.
- Chat screen now shows a clear empty state and a useful Firestore/connection error state.
- The text composer keeps a draft if sending fails, so the user can retry.
- Firestore rules restrict direct chat previews/messages to the two participants and limit read-receipt updates to the recipient.
- Product name is NexChat Android.

## Firestore layout

`users/{userId}/chats/{peerId}` stores the chat preview.

`users/{userId}/chats/{peerId}/messages/{messageId}` stores that user's copy of each message. The same message ID is mirrored under the other participant's chat path. This matches the existing chat stream and read-receipt data model.

## Required Firebase setup

1. Deploy the included `firestore.rules` to Firebase Console → Firestore Database → Rules.
2. Ensure both test accounts have completed the earlier Email OTP/profile flow and have documents at `users/{uid}`.
3. Sign in on two separate devices/accounts and open a direct chat by finding the other account's email.
4. Send messages in both directions; verify live updates, timestamps, reply preview, and read receipt.

## Not claimed as tested

The current execution environment does not have the Flutter SDK. Therefore `flutter analyze`, Android APK build, Firebase live integration, two-device delivery, and deployed Firestore Rules have not been run here. Firebase client configuration is still owned by the user and must be added locally; no private service-account key belongs in the app or chat.

## Scope boundaries

This phase implements direct text chat. Media/voice messages, groups, status, call signalling, push notifications, and native incoming-call behavior remain in their later phases. Existing legacy media/group code remains in the project but is not certified by this phase.
