# Phase 3 — User Profile & Contacts

## Included in this source update
- Editable profile name and About text.
- Profile photo picker and Firebase Storage upload path scoped to the signed-in UID.
- Profile details saved to `users/{uid}` in Firestore.
- Email displayed as read-only account identity.
- Profile route reachable from the dashboard menu.
- Log out action from profile.
- Find People screen: exact email lookup for the email-OTP account model; self-result is filtered; result opens a one-to-one chat route.
- User model reads older documents safely when `about` or `groupId` is missing.
- Dashboard branding changed from WhatsApp to NexChat Android; search opens Find People.

## Backend/security assumptions
- Firestore `users` documents are readable by authenticated users under the current starter rules; users can write only their own document.
- Storage rules must restrict `profilePic/{uid}/...` writes to `request.auth.uid == uid`. A matching `storage.rules` file still needs to be added before production.
- Exact-email lookup is intentionally used instead of downloading the entire users collection. Consider anti-enumeration controls and contact-request/consent workflow before public launch.

## Not yet included / not verified
- Contact invitations, block/report, address-book sync, username/QR discovery.
- Cloudinary media pipeline; this profile-photo source currently uses Firebase Storage.
- Flutter analyze, Android build, and device tests: Flutter SDK is not installed in the authoring environment.
- Firebase/Storage rules deployment and live profile/search tests require the app owner's project.
