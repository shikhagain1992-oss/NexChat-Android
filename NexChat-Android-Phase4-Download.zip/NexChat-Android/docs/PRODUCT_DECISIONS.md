# NexChat Android — Product and Architecture Decisions

## Authentication decision (fixed)
- Email address + one-time email verification code (OTP).
- No SMS OTP and no phone-number authentication flow.
- OTP generation, delivery, expiry, attempt limits, and verification must be handled by a trusted backend.
- Never store or verify OTP secrets only in the Flutter client.

## Platform and architecture
- Android-first Flutter application.
- Kotlin native Android integration for platform-level notifications and call UI.
- Firebase Authentication / Firestore / Cloud Functions / Cloud Messaging for identity, app data, backend workflows, and push delivery.
- Cloudinary for media; signed uploads must be issued by a trusted backend.
- Agora for voice/video calls; RTC tokens must be short-lived and issued by a trusted backend. App Certificates must never ship in the client.

## Product scope
- Profiles and user discovery
- One-to-one and group chats
- Text, emoji, image, video, GIF, audio, and voice messages
- Reply, forward, delete, search, and sent/delivered/read receipts
- Online/offline presence
- 24-hour status updates
- Voice/video calls
- Push notifications including background/locked-screen behavior
- Privacy controls, themes, accessibility, and release packaging

## Release principle
A feature is not marked complete until it is implemented, statically checked, and tested on real Android devices where applicable. Backend-dependent features require configured services and integration tests.
