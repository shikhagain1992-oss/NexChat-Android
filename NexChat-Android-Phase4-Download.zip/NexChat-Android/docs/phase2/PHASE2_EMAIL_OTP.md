# NexChat Android — Phase 2: Email OTP & Session

## Included in this source phase
- Email-only OTP UI (6 digits); SMS/phone OTP screens and client calls removed.
- Flutter client calls trusted Firebase Cloud Functions; client never generates OTPs or stores mail-provider secrets.
- Cloud Functions request/verify endpoints, 5-minute expiry, 60-second resend cooldown, five verification attempts, single-use codes, hashed challenge storage, Firebase custom-token sign-in.
- Native Android launch splash with branded icon and a 2.3-second minimum display. Firebase persisted session is checked while the native splash remains visible; no Flutter loading page is shown before routing.
- Existing signed-in session goes to the app; no session goes to the email landing/login flow.

## Required owner setup (not included in source)
1. Create/choose a Firebase project owned by the app publisher.
2. Enable Authentication custom-token sign-in (Firebase Auth) and create Firestore.
3. Configure FlutterFire for Android, generating `lib/firebase_options.dart` and `android/app/google-services.json` for package `com.nexchat.android`.
4. Deploy Cloud Functions from `functions/` (Node.js 20). Set the secret `RESEND_API_KEY` and parameter `OTP_FROM_EMAIL` to a verified sender in the Resend account.
5. Enable Firebase App Check for Android and deploy App Check enforcement. Until App Check is correctly configured, callable OTP requests are intentionally rejected.
6. Deploy Firestore rules with `firebase deploy --only firestore:rules`.

## Important
- Email OTP delivery cannot work until the app owner configures Firebase, Resend sender/domain and deploys Functions.
- The included rules are a starting point for user profiles and OTP challenge protection; chat/group/status rules must be added in their respective phases before those features are released.
- Email OTP uses a Firebase custom token; it does not use Firebase SMS sign-in or email-link sign-in.
- The 2.3-second splash minimum and session routing are implemented in source but require real-device verification.
