import 'package:flutter_test/flutter_test.dart';
import 'package:nexchat_android/app/screens/setup_required_screen.dart';
import 'package:flutter/material.dart';

void main() {
  testWidgets('NexChat setup screen shows product name', (WidgetTester tester) async {
    await tester.pumpWidget(
      MaterialApp(
        theme: ThemeData(useMaterial3: true),
        home: const SetupRequiredScreen(reason: 'Firebase is not configured.'),
      ),
    );
    expect(find.text('NexChat Android'), findsOneWidget);
    expect(find.text('Firebase setup is required'), findsOneWidget);
  });
}
