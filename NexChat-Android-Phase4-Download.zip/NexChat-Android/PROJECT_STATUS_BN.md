# NexChat Android — কাজের অবস্থা (বাংলা)

## Phase 1: Project Foundation

- [x] নতুন Android application ID: `com.nexchat.android`
- [x] অ্যাপের নাম: `NexChat Android`
- [x] Flutter project-এর package name: `nexchat_android`
- [x] Material 3 ভিত্তিক Light ও Dark theme-এর প্রাথমিক design system
- [x] Firebase configuration না থাকলে crash না করে setup screen দেখানোর ব্যবস্থা
- [x] Email OTP হবে একমাত্র login verification পদ্ধতি—SMS OTP নয়—এই সিদ্ধান্ত নথিভুক্ত
- [x] Firebase/Agora secret client code-এ না রাখার architecture rule নথিভুক্ত

## এখনো বাকি

- [ ] পুরোনো phone-number OTP flow সরিয়ে Email OTP authentication তৈরি
- [ ] নিজস্ব Firebase project এবং secure backend configuration
- [ ] Chat, group, media, status, calls, notifications-এর feature implementation ও testing
- [ ] Dependency migration এবং Flutter analyze/build
- [ ] বাস্তব Android device testing ও release APK/AAB

## যাচাইয়ের সীমাবদ্ধতা

এই environment-এ Flutter SDK পাওয়া যায়নি। তাই `flutter analyze`, Android build বা device test চালানো যায়নি। এই ZIP হলো Phase 1 source update; এটি এখনো সম্পূর্ণ ব্যবহারযোগ্য messaging app বা APK নয়।

**বিশেষ নোট:** পুরোনো prototype-এর ভেতরে phone OTP repository/controller method এখনো আছে, কিন্তু নতুন landing/login UI-তে সেগুলো আর ব্যবহার করা হয় না। Phase 2-তে ওই legacy phone-auth code পুরোপুরি সরিয়ে server-verified Email OTP flow বসানো হবে।

## Phase 2: Email OTP & Session (source implementation)

- [x] Email OTP request/verification UI (৬ সংখ্যার কোড)
- [x] Client থেকে SMS/Phone OTP flow ও OTP route সরানো
- [x] Trusted Firebase Cloud Functions-এ OTP create/hash/expiry/rate limit/attempt limit/single-use verification
- [x] Firebase custom-token sign-in client integration
- [x] Android native splash minimum 2.3 seconds; splash চলাকালীন persisted auth session check
- [x] Session থাকলে Dashboard, না থাকলে Email landing/login
- [x] Firebase Functions ও Firestore rules-এর initial backend source এবং বাংলা setup guide

### Phase 2 এখনও চালু করার জন্য যা বাকি
- [ ] App owner's Firebase project configuration (`firebase_options.dart`, `google-services.json`)
- [ ] Resend verified sender + API secret configure; Cloud Functions deploy
- [ ] Firebase App Check configure (OTP endpoints enforce App Check)
- [ ] Flutter analyze/build এবং real Android splash/login/session/email delivery tests

**গুরুত্বপূর্ণ:** Phase 2-এর source code যোগ হয়েছে, কিন্তু Firebase/Resend credentials বা deploy access ছাড়া OTP বাস্তবে পাঠানো যাবে না। Flutter SDK এই environment-এ নেই, তাই compile/device test করা যায়নি।


## Phase 3: User Profile & Contacts (source implementation)

- [x] Profile screen: নাম, Email, About এবং profile photo দেখা
- [x] নিজের নাম/About সম্পাদনা ও Firestore-এ সংরক্ষণ
- [x] Profile photo Firebase Storage-এ UID-ভিত্তিক path-এ upload
- [x] Dashboard থেকে My Profile ও Log out
- [x] Email দিয়ে নির্দিষ্ট user খোঁজা; নিজের account result হিসেবে না দেখানো
- [x] Search result থেকে one-to-one chat route খোলা
- [x] পুরোনো user document-এ About/groupId না থাকলেও model parsing safe করা
- [x] Profile photo-এর প্রাথমিক Storage rules যোগ

### Phase 3-এর সীমাবদ্ধতা
- Contact invitation/acceptance, block/report, QR/username discovery এখনো বাকি।
- Storage rules deploy এবং profile/search live test করতে মালিকের Firebase project লাগবে।
- Flutter SDK অনুপস্থিত; তাই analyze/build/device test হয়নি।

## Phase 4 — One-to-One Chat (2026-11-02)

- Direct text chat-এর Firestore write path যোগ করা হয়েছে।
- দুই ব্যবহারকারীর chat preview এবং message copy একই Firestore batch-এ লেখা হয়।
- Reply metadata, real-time message stream এবং read receipt-এর আগের UI রাখা হয়েছে।
- Empty/error state এবং failed send হলে draft ধরে রাখার ব্যবস্থা যোগ হয়েছে।
- Firestore rules-এ দুই participant ছাড়া অন্য কারও direct chat পড়া/লেখা সীমাবদ্ধ করা হয়েছে।
- App branding এখন **NexChat Android**।

**পরীক্ষার অবস্থা:** এই পরিবেশে Flutter SDK নেই। তাই Flutter analyze, APK build, Firebase live test, দুই ফোনে message delivery এবং deployed rules যাচাই করা হয়নি। এই phase-এর code প্রস্তুত, কিন্তু live Firebase setup ও device testing বাকি।
