import { createHash, randomInt, timingSafeEqual } from 'crypto';
import { initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { FieldValue, getFirestore } from 'firebase-admin/firestore';
import { defineSecret, defineString } from 'firebase-functions/params';
import { HttpsError, onCall } from 'firebase-functions/v2/https';

initializeApp();
const db = getFirestore();
const resendApiKey = defineSecret('RESEND_API_KEY');
const fromEmail = defineString('OTP_FROM_EMAIL');
const digest = (value: string) => createHash('sha256').update(value).digest('hex');
const validEmail = (value: unknown): value is string => typeof value === 'string' && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value);

export const requestEmailOtp = onCall({ secrets: [resendApiKey], enforceAppCheck: true, maxInstances: 5 }, async (request) => {
  const email = typeof request.data?.email === 'string' ? request.data.email.trim().toLowerCase() : '';
  if (!validEmail(email)) throw new HttpsError('invalid-argument', 'A valid email is required.');
  const id = digest(email);
  const ref = db.collection('emailOtpChallenges').doc(id);
  const now = Date.now();
  const code = randomInt(0, 1000000).toString().padStart(6, '0');
  const codeHash = digest(`${id}:${code}`);

  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const lastSent = snap.exists ? Number(snap.get('lastSentAt') || 0) : 0;
    if (now - lastSent < 60_000) throw new HttpsError('resource-exhausted', 'Please wait before requesting another code.');
    tx.set(ref, { codeHash, expiresAt: now + 5 * 60_000, lastSentAt: now, attempts: 0, consumed: false });
  });

  const response = await fetch('https://api.resend.com/emails', {
    method: 'POST',
    headers: { Authorization: `Bearer ${resendApiKey.value()}`, 'Content-Type': 'application/json' },
    body: JSON.stringify({ from: fromEmail.value(), to: [email], subject: 'Your NexChat Pro sign-in code', text: `Your NexChat Pro verification code is ${code}. It expires in 5 minutes. If you did not request this, ignore this email.` }),
  });
  if (!response.ok) {
    await ref.delete();
    throw new HttpsError('unavailable', 'Email delivery failed. Please try again later.');
  }
  return { sent: true, expiresInSeconds: 300, resendAfterSeconds: 60 };
});

export const verifyEmailOtp = onCall({ enforceAppCheck: true, maxInstances: 5 }, async (request) => {
  const email = typeof request.data?.email === 'string' ? request.data.email.trim().toLowerCase() : '';
  const code = typeof request.data?.code === 'string' ? request.data.code.trim() : '';
  if (!validEmail(email) || !/^\d{6}$/.test(code)) throw new HttpsError('invalid-argument', 'Invalid email or code.');
  const id = digest(email);
  const ref = db.collection('emailOtpChallenges').doc(id);
  const uid = `email_${digest(email).slice(0, 48)}`;
  const valid = await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    if (!snap.exists) return false;
    const data = snap.data()!;
    if (data.consumed || Number(data.expiresAt) < Date.now() || Number(data.attempts) >= 5) {
      tx.delete(ref); return false;
    }
    const expected = Buffer.from(String(data.codeHash), 'hex');
    const actual = Buffer.from(digest(`${id}:${code}`), 'hex');
    const matches = expected.length === actual.length && timingSafeEqual(expected, actual);
    if (!matches) {
      tx.update(ref, { attempts: FieldValue.increment(1) });
      return false;
    }
    tx.delete(ref);
    return true;
  });
  if (!valid) throw new HttpsError('permission-denied', 'The code is incorrect or expired. Request a new code.');

  try {
    await getAuth().getUser(uid);
  } catch {
    await getAuth().createUser({ uid, email, emailVerified: true, displayName: email.split('@')[0] });
  }
  const customToken = await getAuth().createCustomToken(uid, { emailVerified: true });
  return { customToken };
});
