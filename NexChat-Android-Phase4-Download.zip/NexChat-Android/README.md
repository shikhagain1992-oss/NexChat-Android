# NexChat Android — NexChat-Android

Android-first Flutter messaging app project. This is the new NexChat Android workspace; the older `sayan` and `nexchat-pro` repositories are separate and are not modified.

## Authentication requirement

**Email address + email OTP only. SMS OTP and phone-number authentication are out of scope.** OTP generation, delivery, expiry, attempt limits and verification must be implemented on a trusted backend. Do not verify OTPs only in the mobile client.

## Planned product scope

- Email OTP authentication and user profiles
- One-to-one and group conversations
- Text, image, video, GIF, emoji, audio and voice messages
- Reply, forward, delete, search and sent/delivered/read receipts
- Online/offline presence
- 24-hour status updates
- Voice and video calling
- Push notifications and Android incoming-call experience
- Secure media uploads and downloads
- Material 3 interface, dark/light themes and responsive layouts

## Architecture

- Flutter: app UI and client logic
- Kotlin: Android-native notification and incoming-call integration
- Firebase: identity, Firestore, Cloud Functions and push messaging
- Cloudinary: media storage (signed uploads via backend)
- Agora: voice/video calls (short-lived RTC tokens from backend)

## Setup status

Firebase configuration from the unrelated upstream project has intentionally been removed. Add your own Firebase Android app configuration and regenerate FlutterFire options before connecting backend features. The app now shows a setup-required screen if Firebase is not configured.

Never put service-account keys, Cloudinary API secrets, or Agora App Certificates in Flutter source code. Rotate any previously exposed Agora App Certificate.

## Verification status

Phase 1 foundation source changes are prepared. Flutter analyze/build, Firebase integration, two-device chat/call tests and release APK/AAB have **not** been run. The inherited prototype still needs dependency migration and feature rewrites before release.

The previous prototype's internal phone-auth repository methods are scheduled for removal in Phase 2. They are no longer exposed by the new landing/login screens and must not be used.


## Current milestone
Phase 2 adds the email-only OTP client and trusted Firebase Functions source, plus native splash/session routing. See `PHASE2_SETUP_BN.md` and `docs/phase2/PHASE2_EMAIL_OTP.md` before configuring your own Firebase/Resend services. The source has not yet been compiled or device-tested in this environment.


## Phase 3 update
Profile editing, profile-photo upload, logout, and exact-email people search source have been added. See `docs/phase3/PHASE3_PROFILE_CONTACTS.md` and `PROJECT_STATUS_BN.md`. These features still require the owner's Firebase Firestore/Storage setup and deployed rules.

## Current phase

Phase 4 (One-to-One Chat) adds Firestore-backed direct text messaging, mirrored chat previews/messages in a batch, reply metadata, read receipts, safer chat-specific Firestore rules, and empty/error states. See `docs/phase4/PHASE4_ONE_TO_ONE_CHAT.md` for setup and test steps.

The product name is **NexChat Android**. Flutter/Firebase build and live multi-device testing have not yet been run in this environment.
